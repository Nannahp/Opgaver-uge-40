package Vehicles;

public class Car extends Vehicle {
    public void drive() {

        System.out.println("Car is driving");

    }
}