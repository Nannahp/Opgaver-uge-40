package Vehicles;

public class Ship extends Vehicle{


    public void sail() {

        System.out.println("Ship is sailing");

    }

}