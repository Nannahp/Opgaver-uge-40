package Vehicles;

public class Plane extends Vehicle {

    public void fly() {

        System.out.println("Plane is flying");
    }
}