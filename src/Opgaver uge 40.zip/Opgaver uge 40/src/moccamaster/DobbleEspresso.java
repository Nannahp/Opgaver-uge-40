package moccamaster;

public class DobbleEspresso extends  Cup {
    public DobbleEspresso(){
        super("Double Espresso");
    }


    public void showCup() {
        System.out.println(name);
    }
}
