package moccamaster;

public class Cup {
    String name;

    public Cup(String name){
        this.name = name;
    }


    public void showCup() {
        System.out.println(name +" Cup");
    }
}
