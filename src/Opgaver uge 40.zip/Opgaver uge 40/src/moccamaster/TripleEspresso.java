package moccamaster;

public class TripleEspresso extends Cup{

    public TripleEspresso(){
        super("Tripple espresso");
    }

    public void showCup() {
        System.out.println(name);
    }
}
