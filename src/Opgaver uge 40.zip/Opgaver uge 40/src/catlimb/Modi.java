package catlimb;

public enum Modi {
    ONLY_IN,
    ONLY_OUT,
    IN_OUT,
    CLOSED,

}
